import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { items, insertItemSchema } from '@/lib/schema';
import { desc, asc, or, ilike, eq, sql } from 'drizzle-orm';

// GET /api/items - List all items with optional search, filter, and pagination
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const status = searchParams.get('status') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const sortBy = searchParams.get('sortBy') || 'createdAt';
    const sortOrder = searchParams.get('sortOrder') || 'desc';
    const format = searchParams.get('format');

    const offset = (page - 1) * limit;

    // Build the where clause
    const whereConditions = [];
    
    if (search) {
      whereConditions.push(
        or(
          ilike(items.title, `%${search}%`),
          ilike(items.description, `%${search}%`)
        )
      );
    }
    
    if (category) {
      whereConditions.push(eq(items.category, category));
    }
    
    if (status) {
      whereConditions.push(eq(items.status, status));
    }

    // Build base query with filters
    const whereClause = whereConditions.length > 0 
      ? sql`${sql.join(whereConditions, sql` AND `)}`
      : undefined;

    // Get total count for pagination (with filters applied)
    let countQuery = db
      .select({ count: sql<number>`count(*)` })
      .from(items);
    
    if (whereClause) {
      countQuery = countQuery.where(whereClause);
    }
    
    const [{ count: total }] = await countQuery;

    // Handle CSV/JSON export - export ALL filtered data, not just current page
    if (format === 'csv' || format === 'json') {
      let exportQuery = db
        .select()
        .from(items);
      
      if (whereClause) {
        exportQuery = exportQuery.where(whereClause);
      }
      
      const allData = await exportQuery;
      
      if (format === 'csv') {
        const csvHeader = 'ID,Title,Description,Category,Status,Created At,Updated At\n';
        const csvRows = allData.map(item => 
          `"${item.id}","${item.title}","${item.description || ''}","${item.category || ''}","${item.status}","${item.createdAt}","${item.updatedAt}"`
        ).join('\n');
        
        return new NextResponse(csvHeader + csvRows, {
          headers: {
            'Content-Type': 'text/csv',
            'Content-Disposition': 'attachment; filename="items.csv"',
          },
        });
      } else {
        // JSON export
        return NextResponse.json(allData, {
          headers: {
            'Content-Disposition': 'attachment; filename="items.json"',
          },
        });
      }
    }

    // Get items with sorting and pagination for normal requests
    const orderByColumn = sortBy === 'title' ? items.title 
      : sortBy === 'category' ? items.category
      : sortBy === 'status' ? items.status
      : items.createdAt;
    
    const orderByFunc = sortOrder === 'asc' ? asc : desc;
    
    let query = db
      .select()
      .from(items)
      .orderBy(orderByFunc(orderByColumn))
      .limit(limit)
      .offset(offset);
    
    if (whereClause) {
      query = query.where(whereClause);
    }
    
    const data = await query;

    // Return JSON response with pagination metadata
    return NextResponse.json({
      data,
      pagination: {
        page,
        limit,
        total: Number(total),
        totalPages: Math.ceil(Number(total) / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching items:', error);
    return NextResponse.json(
      { error: 'Failed to fetch items' },
      { status: 500 }
    );
  }
}

// POST /api/items - Create a new item
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const validatedData = insertItemSchema.parse(body);
    
    const [newItem] = await db
      .insert(items)
      .values({
        ...validatedData,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();

    return NextResponse.json(newItem, { status: 201 });
  } catch (error: any) {
    console.error('Error creating item:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to create item' },
      { status: 400 }
    );
  }
}
