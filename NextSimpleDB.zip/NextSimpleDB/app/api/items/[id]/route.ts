import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { items, insertItemSchema } from '@/lib/schema';
import { eq } from 'drizzle-orm';

// GET /api/items/[id] - Get a single item
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const [item] = await db
      .select()
      .from(items)
      .where(eq(items.id, params.id))
      .limit(1);

    if (!item) {
      return NextResponse.json(
        { error: 'Item not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(item);
  } catch (error) {
    console.error('Error fetching item:', error);
    return NextResponse.json(
      { error: 'Failed to fetch item' },
      { status: 500 }
    );
  }
}

// PATCH /api/items/[id] - Update an item
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const validatedData = insertItemSchema.partial().parse(body);

    const [updatedItem] = await db
      .update(items)
      .set({
        ...validatedData,
        updatedAt: new Date(),
      })
      .where(eq(items.id, params.id))
      .returning();

    if (!updatedItem) {
      return NextResponse.json(
        { error: 'Item not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(updatedItem);
  } catch (error: any) {
    console.error('Error updating item:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to update item' },
      { status: 400 }
    );
  }
}

// DELETE /api/items/[id] - Delete an item
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const [deletedItem] = await db
      .delete(items)
      .where(eq(items.id, params.id))
      .returning();

    if (!deletedItem) {
      return NextResponse.json(
        { error: 'Item not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting item:', error);
    return NextResponse.json(
      { error: 'Failed to delete item' },
      { status: 500 }
    );
  }
}
