#!/bin/bash
cd /home/runner/workspace
PORT=5000 npx next dev -p 5000
