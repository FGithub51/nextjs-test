var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/items/route.js")
R.c("server/chunks/node_modules_next_1f9a9a9b._.js")
R.c("server/chunks/node_modules_drizzle-orm_21e9f2f5._.js")
R.c("server/chunks/node_modules_zod_v3_f358d7b3._.js")
R.c("server/chunks/node_modules_77fed8d4._.js")
R.c("server/chunks/[root-of-the-server]__2a676d6e._.js")
R.c("server/chunks/_next-internal_server_app_api_items_route_actions_c8104f30.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/items/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/items/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
