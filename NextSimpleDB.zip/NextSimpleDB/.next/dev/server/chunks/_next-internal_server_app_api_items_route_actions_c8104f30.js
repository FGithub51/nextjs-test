module.exports = [
"[project]/.next-internal/server/app/api/items/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=_next-internal_server_app_api_items_route_actions_c8104f30.js.map